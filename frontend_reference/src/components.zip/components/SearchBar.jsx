﻿import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
/*import SearchBar from 'material-ui-search-bar';*/

/*export default class SearchBarS extends Component {
    render() {
        return (
            <div>
                <SearchBar
                    value={this.state.value}
                    onChange={(newValue) => this.setState({ value: newValue })}
                    onRequestSearch={() => doSomethingWith(this.state.value)}
                    style={{
                        margin: '0 auto',
                        maxWidth: 800
                    }}
                />
            </div>
        )
    }
}*/